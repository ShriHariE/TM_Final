﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using TrendyMart.Models;

namespace TrendyMart.Services
{
    public class JwtService
    {
        private readonly IConfiguration _config;
        private readonly byte[] _key;
        private readonly string _issuer;
        private readonly string _audience;
        private readonly double _expireMinutes;

        public JwtService(IConfiguration config)
        {
            _config = config;

            // Read from appsettings.json
            _key = Encoding.UTF8.GetBytes(_config["Jwt:Key"] ?? throw new ArgumentNullException("Jwt:Key missing in config"));
            _issuer = _config["Jwt:Issuer"] ?? throw new ArgumentNullException("Jwt:Issuer missing in config");
            _audience = _config["Jwt:Audience"] ?? throw new ArgumentNullException("Jwt:Audience missing in config");
            _expireMinutes = Convert.ToDouble(_config["Jwt:ExpireMinutes"] ?? "60");
        }

        // ✅ Generate Access Token
        public string GenerateToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            // Claims (can add more if needed)
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.FullName ?? string.Empty),
                new Claim(ClaimTypes.Email, user.Email ?? string.Empty),
                new Claim(ClaimTypes.Role, user.Role ?? "User")
            };

            var credentials = new SigningCredentials(
                new SymmetricSecurityKey(_key),
                SecurityAlgorithms.HmacSha256
            );

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(_expireMinutes),
                Issuer = _issuer,
                Audience = _audience,
                SigningCredentials = credentials
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        // ✅ Optional: Generate Refresh Token
        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using var rng = System.Security.Cryptography.RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
    }
}
