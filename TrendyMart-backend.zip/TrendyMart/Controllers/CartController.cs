﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Authorize] // Requires JWT token for all endpoints unless marked AllowAnonymous
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _cartRepo;
        private readonly ICartItemRepository _cartItemRepo;
        private readonly IUserRepository _userRepo;

        public CartController(ICartRepository cartRepo, ICartItemRepository cartItemRepo, IUserRepository userRepo)
        {
            _cartRepo = cartRepo;
            _cartItemRepo = cartItemRepo;
            _userRepo = userRepo;
        }

        // GET: All Carts with Items
        [HttpGet]
        [AllowAnonymous] // Remove this if you want only authenticated users to view all carts
        public ActionResult<IEnumerable<CartDto>> GetAllCarts()
        {
            var carts = _cartRepo.GetAllCarts();

            var cartDtos = carts.Select(cart => new CartDto
            {
                CartId = cart.CartId,
                UserName = _userRepo.GetById(cart.UserId)?.FullName ?? "Unknown User",
                CreatedAt = cart.CreatedAt,
                Items = _cartItemRepo.GetItemsByCartId(cart.CartId)
                    .Select(item => new CartItemDto
                    {
                        CartItemId = item.CartItemId,
                        ProductName = item.Product?.ProductName ?? "Unknown Product",
                        Quantity = item.Quantity,
                        Price = item.Product?.Price ?? 0
                    }).ToList()
            });

            return Ok(cartDtos);
        }

        // GET: Single Cart by ID
        [HttpGet("{id}")]
        public ActionResult<CartDto> GetCartById(int id)
        {
            var cart = _cartRepo.GetCartById(id);
            if (cart == null)
                return NotFound($"Cart with ID {id} not found.");

            var cartDto = new CartDto
            {
                CartId = cart.CartId,
                UserName = _userRepo.GetById(cart.UserId)?.FullName ?? "Unknown User",
                CreatedAt = cart.CreatedAt,
                Items = _cartItemRepo.GetItemsByCartId(cart.CartId)
                    .Select(item => new CartItemDto
                    {
                        CartItemId = item.CartItemId,
                        ProductName = item.Product?.ProductName ?? "Unknown Product",
                        Quantity = item.Quantity,
                        Price = item.Product?.Price ?? 0
                    }).ToList()
            };

            return Ok(cartDto);
        }

        // POST: Add Cart
        [HttpPost]
        public ActionResult<CartDto> AddCart([FromBody] Cart cart)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _cartRepo.AddCart(cart);

            var createdCartDto = new CartDto
            {
                CartId = cart.CartId,
                UserName = _userRepo.GetById(cart.UserId)?.FullName ?? "Unknown User",
                CreatedAt = cart.CreatedAt,
                Items = new List<CartItemDto>() // New cart initially empty
            };

            return CreatedAtAction(nameof(GetCartById), new { id = cart.CartId }, createdCartDto);
        }

        // DELETE: Remove Cart
        [HttpDelete("{id}")]
        public ActionResult DeleteCart(int id)
        {
            if (!_cartRepo.CartExists(id))
                return NotFound($"Cart with ID {id} not found.");

            _cartRepo.DeleteCart(id);
            return NoContent();
        }
    }
}
