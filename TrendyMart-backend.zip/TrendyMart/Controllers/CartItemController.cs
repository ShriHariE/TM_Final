﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Authorize] // Require JWT for all endpoints
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CartItemController : ControllerBase
    {
        private readonly ICartItemRepository _cartItemRepo;
        private readonly IProductRepository _productRepo;

        public CartItemController(ICartItemRepository cartItemRepo, IProductRepository productRepo)
        {
            _cartItemRepo = cartItemRepo;
            _productRepo = productRepo;
        }

        // GET: All Cart Items
        [HttpGet]
        public ActionResult<IEnumerable<CartItemDto>> GetAll()
        {
            var items = _cartItemRepo.GetAll();

            var itemDtos = items.Select(i => new CartItemDto
            {
                CartItemId = i.CartItemId,
                ProductName = i.Product?.ProductName ?? "Unknown Product",
                Quantity = i.Quantity,
                Price = i.Product?.Price ?? 0
            });

            return Ok(itemDtos);
        }

        // GET: Single Cart Item by ID
        [HttpGet("{id}")]
        public ActionResult<CartItemDto> GetById(int id)
        {
            var item = _cartItemRepo.GetById(id);
            if (item == null)
                return NotFound($"CartItem with ID {id} not found.");

            var itemDto = new CartItemDto
            {
                CartItemId = item.CartItemId,
                ProductName = item.Product?.ProductName ?? "Unknown Product",
                Quantity = item.Quantity,
                Price = item.Product?.Price ?? 0
            };

            return Ok(itemDto);
        }

        // GET: Items by Cart ID
        [HttpGet("{cartId}")]
        public ActionResult<IEnumerable<CartItemDto>> GetItemsByCartId(int cartId)
        {
            var items = _cartItemRepo.GetItemsByCartId(cartId);

            if (!items.Any())
                return NotFound($"No items found for Cart ID {cartId}");

            var itemDtos = items.Select(i => new CartItemDto
            {
                CartItemId = i.CartItemId,
                ProductName = i.Product?.ProductName ?? "Unknown Product",
                Quantity = i.Quantity,
                Price = i.Product?.Price ?? 0
            });

            return Ok(itemDtos);
        }

        // POST: Add new Cart Item
        [HttpPost]
        public ActionResult<CartItemDto> Add([FromBody] CartItem item)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _cartItemRepo.Add(item);

            var product = _productRepo.GetById(item.ProductId);

            var createdDto = new CartItemDto
            {
                CartItemId = item.CartItemId,
                ProductName = product?.ProductName ?? "Unknown Product",
                Quantity = item.Quantity,
                Price = product?.Price ?? 0
            };

            return CreatedAtAction(nameof(GetById), new { id = item.CartItemId }, createdDto);
        }

        // PUT: Update Cart Item
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] CartItem item)
        {
            if (id != item.CartItemId)
                return BadRequest("CartItem ID mismatch.");

            var existing = _cartItemRepo.GetById(id);
            if (existing == null)
                return NotFound($"CartItem with ID {id} not found.");

            _cartItemRepo.Update(item);
            return NoContent();
        }

        // DELETE: Remove Cart Item
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var existing = _cartItemRepo.GetById(id);
            if (existing == null)
                return NotFound($"CartItem with ID {id} not found.");

            _cartItemRepo.Delete(id);
            return NoContent();
        }
    }
}
