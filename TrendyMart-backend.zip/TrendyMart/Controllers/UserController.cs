﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;
using TrendyMart.Services;
using System.Linq;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepo;
        private readonly JwtService _jwtService;

        public UserController(IUserRepository userRepo, JwtService jwtService)
        {
            _userRepo = userRepo;
            _jwtService = jwtService;
        }

        // 1. LOGIN - Public
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login([FromBody] LoginDto login)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = _userRepo.GetAll()
                .FirstOrDefault(u => u.Email == login.Email && u.Password == login.Password && u.IsActive);

            if (user == null)
                return Unauthorized("Invalid email or password");

            var token = _jwtService.GenerateToken(user);

            return Ok(new
            {
                Token = token,
                User = new
                {
                    user.UserId,
                    user.FullName,
                    user.Email,
                    user.Role
                }
            });
        }

        // 2. GET ALL USERS - Admin Only
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult<IEnumerable<UserDto>> GetAllUsers()
        {
            var users = _userRepo.GetAll();

            var userDtos = users.Select(u => new UserDto
            {
                UserId = u.UserId,
                FullName = u.FullName,
                Email = u.Email,
                Gender = u.Gender,
                ContactNumber = u.ContactNumber,
                Address = u.Address,
                Role = u.Role,
                IsActive = u.IsActive,
                CreatedAt = u.CreatedAt
            }).ToList();

            return Ok(userDtos);
        }

        // 3. GET USER BY ID - Admin Only
        [HttpGet("{id}")]
        [Authorize(Roles = "Admin")]
        public ActionResult<UserDto> GetUserById(int id)
        {
            var user = _userRepo.GetById(id);
            if (user == null)
                return NotFound($"User with ID {id} not found.");

            var userDto = new UserDto
            {
                UserId = user.UserId,
                FullName = user.FullName,
                Email = user.Email,
                Gender = user.Gender,
                ContactNumber = user.ContactNumber,
                Address = user.Address,
                Role = user.Role,
                IsActive = user.IsActive,
                CreatedAt = user.CreatedAt
            };

            return Ok(userDto);
        }

        // 4. REGISTER USER - Public
        [HttpPost]
        [AllowAnonymous]
        public ActionResult<UserDto> AddUser([FromBody] User user)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (string.IsNullOrEmpty(user.Role))
                user.Role = "User";

            _userRepo.Add(user);

            var userDto = new UserDto
            {
                UserId = user.UserId,
                FullName = user.FullName,
                Email = user.Email,
                Gender = user.Gender,
                ContactNumber = user.ContactNumber,
                Address = user.Address,
                Role = user.Role,
                IsActive = user.IsActive,
                CreatedAt = user.CreatedAt
            };

            return CreatedAtAction(nameof(GetUserById), new { id = user.UserId }, userDto);
        }

        // 5. UPDATE USER - Admin Only
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public ActionResult UpdateUser(int id, [FromBody] User user)
        {
            if (id != user.UserId)
                return BadRequest("User ID mismatch.");

            if (!_userRepo.Exists(id))
                return NotFound($"User with ID {id} not found.");

            _userRepo.Update(user);
            return NoContent();
        }

        // 6. DELETE USER - Admin Only
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteUser(int id)
        {
            if (!_userRepo.Exists(id))
                return NotFound($"User with ID {id} not found.");

            _userRepo.Delete(id);
            return NoContent();
        }
    }
}
