﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Authorize] // Protect with JWT
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentRepository _paymentRepo;
        private readonly IOrderRepository _orderRepo;
        private readonly IUserRepository _userRepo;

        public PaymentController(IPaymentRepository paymentRepo, IOrderRepository orderRepo, IUserRepository userRepo)
        {
            _paymentRepo = paymentRepo;
            _orderRepo = orderRepo;
            _userRepo = userRepo;
        }

        // GET: All Payments
        [HttpGet]
        public ActionResult<IEnumerable<PaymentDto>> GetAll()
        {
            var payments = _paymentRepo.GetAll();

            var paymentDtos = payments.Select(p =>
            {
                var order = _orderRepo.GetById(p.OrderId);
                var userName = order != null
                    ? _userRepo.GetById(order.UserId)?.FullName ?? "Unknown User"
                    : "Unknown User";

                return new PaymentDto
                {
                    PaymentId = p.PaymentId,
                    OrderId = p.OrderId,
                    PaymentMode = p.PaymentMode,
                    PaymentDate = p.PaymentDate,
                    Amount = p.Amount,
                    UserName = userName
                };
            });

            return Ok(paymentDtos);
        }

        // GET: Single Payment
        [HttpGet("{id}")]
        public ActionResult<PaymentDto> GetById(int id)
        {
            var payment = _paymentRepo.GetById(id);
            if (payment == null)
                return NotFound($"Payment with ID {id} not found.");

            var order = _orderRepo.GetById(payment.OrderId);
            var userName = order != null
                ? _userRepo.GetById(order.UserId)?.FullName ?? "Unknown User"
                : "Unknown User";

            var paymentDto = new PaymentDto
            {
                PaymentId = payment.PaymentId,
                OrderId = payment.OrderId,
                PaymentMode = payment.PaymentMode,
                PaymentDate = payment.PaymentDate,
                Amount = payment.Amount,
                UserName = userName
            };

            return Ok(paymentDto);
        }

        // POST: Add Payment
        [HttpPost]
        public ActionResult<PaymentDto> Add([FromBody] Payment payment)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Check if the order exists before adding payment
            if (_orderRepo.GetById(payment.OrderId) == null)
                return NotFound($"Order with ID {payment.OrderId} not found.");

            _paymentRepo.Add(payment);

            var order = _orderRepo.GetById(payment.OrderId);
            var userName = order != null
                ? _userRepo.GetById(order.UserId)?.FullName ?? "Unknown User"
                : "Unknown User";

            var createdDto = new PaymentDto
            {
                PaymentId = payment.PaymentId,
                OrderId = payment.OrderId,
                PaymentMode = payment.PaymentMode,
                PaymentDate = payment.PaymentDate,
                Amount = payment.Amount,
                UserName = userName
            };

            return CreatedAtAction(nameof(GetById), new { id = payment.PaymentId }, createdDto);
        }

        // PUT: Update Payment
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] Payment payment)
        {
            if (id != payment.PaymentId)
                return BadRequest("Payment ID mismatch.");

            if (!_paymentRepo.Exists(id))
                return NotFound($"Payment with ID {id} not found.");

            _paymentRepo.Update(payment);
            return NoContent();
        }

        // DELETE: Remove Payment
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (!_paymentRepo.Exists(id))
                return NotFound($"Payment with ID {id} not found.");

            _paymentRepo.Delete(id);
            return NoContent();
        }
    }
}
