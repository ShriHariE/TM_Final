﻿using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepo;
        private readonly IProductCategoryRepository _categoryRepo;
        private readonly IUserRepository _userRepo;

        public ProductController(IProductRepository productRepo, IProductCategoryRepository categoryRepo, IUserRepository userRepo)
        {
            _productRepo = productRepo;
            _categoryRepo = categoryRepo;
            _userRepo = userRepo;
        }

        // GET: api/Product/GetAllProducts
        [HttpGet]
        public ActionResult<IEnumerable<ProductDto>> GetAllProducts()
        {
            var products = _productRepo.GetAll();

            var productDtos = products.Select(p => new ProductDto
            {
                ProductId = p.ProductId,
                ProductName = p.ProductName,
                Description = p.Description,
                Price = p.Price,
                Stock = p.Stock,
                ImageUrl = p.ImageUrl,
                CategoryId = p.CategoryId,
                CategoryName = _categoryRepo.GetById(p.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = p.SellerId,
                SellerName = _userRepo.GetById(p.SellerId)?.FullName ?? "Unknown",
                IsActive = p.IsActive
            }).ToList();

            return Ok(productDtos);
        }

        // GET: api/Product/GetProductById/5
        [HttpGet("{id}")]
        public ActionResult<ProductDto> GetProductById(int id)
        {
            var product = _productRepo.GetById(id);
            if (product == null)
                return NotFound("Product with ID " + id + " not found");

            var dto = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                ImageUrl = product.ImageUrl,
                CategoryId = product.CategoryId,
                CategoryName = _categoryRepo.GetById(product.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = product.SellerId,
                SellerName = _userRepo.GetById(product.SellerId)?.FullName ?? "Unknown",
                IsActive = product.IsActive
            };

            return Ok(dto);
        }

        // POST: api/Product/AddProduct
        [HttpPost]
        public ActionResult<ProductDto> AddProduct([FromBody] Product product)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _productRepo.Add(product);

            var dto = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                ImageUrl = product.ImageUrl,
                CategoryId = product.CategoryId,
                CategoryName = _categoryRepo.GetById(product.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = product.SellerId,
                SellerName = _userRepo.GetById(product.SellerId)?.FullName ?? "Unknown",
                IsActive = product.IsActive
            };

            return CreatedAtAction(nameof(GetProductById), new { id = product.ProductId }, dto);
        }

        // PUT: api/Product/UpdateProduct/5
        [HttpPut("{id}")]
        public ActionResult UpdateProduct(int id, [FromBody] Product product)
        {
            if (id != product.ProductId)
                return BadRequest("Product ID mismatch");

            if (!_productRepo.Exists(id))
                return NotFound("Product with ID " + id + " not found");

            _productRepo.Update(product);
            return NoContent();
        }

        // DELETE: api/Product/DeleteProduct/5
        [HttpDelete("{id}")]
        public ActionResult DeleteProduct(int id)
        {
            if (!_productRepo.Exists(id))
                return NotFound("Product with ID " + id + " not found");

            _productRepo.Delete(id);
            return NoContent();
        }
    }
}
