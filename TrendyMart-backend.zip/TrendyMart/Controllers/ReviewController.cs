﻿using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewRepository _reviewRepo;
        private readonly IProductRepository _productRepo;
        private readonly IUserRepository _userRepo;

        public ReviewController(IReviewRepository reviewRepo, IProductRepository productRepo, IUserRepository userRepo)
        {
            _reviewRepo = reviewRepo;
            _productRepo = productRepo;
            _userRepo = userRepo;
        }

        // GET: api/Review/GetAll
        [HttpGet]
        public ActionResult<IEnumerable<ReviewDto>> GetAll()
        {
            var reviews = _reviewRepo.GetAll();

            var reviewDtos = reviews.Select(r => new ReviewDto
            {
                ReviewId = r.ReviewId,
                ProductId = r.ProductId,
                ProductName = _productRepo.GetById(r.ProductId)?.ProductName ?? "Unknown Product",
                UserId = r.UserId,
                UserName = _userRepo.GetById(r.UserId)?.FullName ?? "Unknown User",
                Rating = r.Rating,
                Comment = r.Comment,
                ReviewDate = r.ReviewDate
            }).ToList();

            return Ok(reviewDtos);
        }

        // GET: api/Review/GetById/5
        [HttpGet("{id}")]
        public ActionResult<ReviewDto> GetById(int id)
        {
            var review = _reviewRepo.GetById(id);
            if (review == null)
                return NotFound($"Review with ID {id} not found.");

            var reviewDto = new ReviewDto
            {
                ReviewId = review.ReviewId,
                ProductId = review.ProductId,
                ProductName = _productRepo.GetById(review.ProductId)?.ProductName ?? "Unknown Product",
                UserId = review.UserId,
                UserName = _userRepo.GetById(review.UserId)?.FullName ?? "Unknown User",
                Rating = review.Rating,
                Comment = review.Comment,
                ReviewDate = review.ReviewDate
            };

            return Ok(reviewDto);
        }

        // GET: api/Review/GetByProductId/2
        [HttpGet("{productId}")]
        public ActionResult<IEnumerable<ReviewDto>> GetByProductId(int productId)
        {
            var productReviews = _reviewRepo.GetByProductId(productId);

            if (!productReviews.Any())
                return NotFound($"No reviews found for product ID: {productId}");

            var reviewDtos = productReviews.Select(r => new ReviewDto
            {
                ReviewId = r.ReviewId,
                ProductId = r.ProductId,
                ProductName = _productRepo.GetById(r.ProductId)?.ProductName ?? "Unknown Product",
                UserId = r.UserId,
                UserName = _userRepo.GetById(r.UserId)?.FullName ?? "Unknown User",
                Rating = r.Rating,
                Comment = r.Comment,
                ReviewDate = r.ReviewDate
            }).ToList();

            return Ok(reviewDtos);
        }

        // POST: api/Review/Add
        [HttpPost]
        public ActionResult<ReviewDto> Add([FromBody] Review review)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _reviewRepo.Add(review);

            var createdDto = new ReviewDto
            {
                ReviewId = review.ReviewId,
                ProductId = review.ProductId,
                ProductName = _productRepo.GetById(review.ProductId)?.ProductName ?? "Unknown Product",
                UserId = review.UserId,
                UserName = _userRepo.GetById(review.UserId)?.FullName ?? "Unknown User",
                Rating = review.Rating,
                Comment = review.Comment,
                ReviewDate = review.ReviewDate
            };

            return CreatedAtAction(nameof(GetById), new { id = review.ReviewId }, createdDto);
        }

        // PUT: api/Review/Update/5
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] Review review)
        {
            if (id != review.ReviewId)
                return BadRequest("Review ID mismatch");

            if (!_reviewRepo.Exists(id))
                return NotFound($"Review with ID {id} not found.");

            _reviewRepo.Update(review);
            return NoContent();
        }

        // DELETE: api/Review/Delete/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (!_reviewRepo.Exists(id))
                return NotFound($"Review with ID {id} not found.");

            _reviewRepo.Delete(id);
            return NoContent();
        }
    }
}
