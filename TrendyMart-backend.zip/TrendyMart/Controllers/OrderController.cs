﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Authorize] // Require JWT for all endpoints
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepo;
        private readonly IProductRepository _productRepo;
        private readonly IUserRepository _userRepo;

        public OrderController(IOrderRepository orderRepo, IProductRepository productRepo, IUserRepository userRepo)
        {
            _orderRepo = orderRepo;
            _productRepo = productRepo;
            _userRepo = userRepo;
        }

        // GET: All Orders
        [HttpGet]
        public ActionResult<IEnumerable<OrderDto>> GetAll()
        {
            var orders = _orderRepo.GetAll();

            var orderDtos = orders.Select(o => new OrderDto
            {
                OrderId = o.OrderId,
                UserName = _userRepo.GetById(o.UserId)?.FullName ?? "Unknown User",
                OrderDate = o.OrderDate,
                TotalAmount = o.TotalAmount,
                ShippingAddress = o.ShippingAddress,
                PaymentStatus = o.PaymentStatus,
                Items = _orderRepo.GetOrderItems(o.OrderId).Select(i => new OrderItemDto
                {
                    OrderItemId = i.OrderItemId,
                    ProductName = i.Product?.ProductName ?? "Unknown Product",
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList()
            });

            return Ok(orderDtos);
        }

        // GET: Single Order
        [HttpGet("{id}")]
        public ActionResult<OrderDto> GetById(int id)
        {
            var order = _orderRepo.GetById(id);
            if (order == null)
                return NotFound($"Order with ID {id} not found.");

            var orderDto = new OrderDto
            {
                OrderId = order.OrderId,
                UserName = _userRepo.GetById(order.UserId)?.FullName ?? "Unknown User",
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                ShippingAddress = order.ShippingAddress,
                PaymentStatus = order.PaymentStatus,
                Items = _orderRepo.GetOrderItems(order.OrderId).Select(i => new OrderItemDto
                {
                    OrderItemId = i.OrderItemId,
                    ProductName = i.Product?.ProductName ?? "Unknown Product",
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList()
            };

            return Ok(orderDto);
        }

        // POST: Create new Order
        [HttpPost]
        public ActionResult<OrderDto> Add([FromBody] Order order)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _orderRepo.Add(order);

            var createdDto = new OrderDto
            {
                OrderId = order.OrderId,
                UserName = _userRepo.GetById(order.UserId)?.FullName ?? "Unknown User",
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                ShippingAddress = order.ShippingAddress,
                PaymentStatus = order.PaymentStatus,
                Items = new List<OrderItemDto>() // Initially empty
            };

            return CreatedAtAction(nameof(GetById), new { id = order.OrderId }, createdDto);
        }

        // PUT: Update Order
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] Order order)
        {
            if (id != order.OrderId)
                return BadRequest("Order ID mismatch.");

            if (!_orderRepo.Exists(id))
                return NotFound($"Order with ID {id} not found.");

            _orderRepo.Update(order);
            return NoContent();
        }

        // DELETE: Remove Order
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (!_orderRepo.Exists(id))
                return NotFound($"Order with ID {id} not found.");

            _orderRepo.Delete(id);
            return NoContent();
        }

        // GET: Order Items by Order ID
        [HttpGet("{orderId}")]
        public ActionResult<IEnumerable<OrderItemDto>> GetOrderItems(int orderId)
        {
            var items = _orderRepo.GetOrderItems(orderId);

            if (!items.Any())
                return NotFound($"No items found for Order ID {orderId}");

            var itemDtos = items.Select(i => new OrderItemDto
            {
                OrderItemId = i.OrderItemId,
                ProductName = i.Product?.ProductName ?? "Unknown Product",
                Quantity = i.Quantity,
                Price = i.Price
            });

            return Ok(itemDtos);
        }

        // POST: Add Order Item
        [HttpPost]
        public ActionResult<OrderItemDto> AddOrderItem([FromBody] OrderItem item)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (_productRepo.GetById(item.ProductId) == null)
                return NotFound($"Product with ID {item.ProductId} not found.");

            _orderRepo.AddOrderItem(item);

            var createdDto = new OrderItemDto
            {
                OrderItemId = item.OrderItemId,
                ProductName = _productRepo.GetById(item.ProductId)?.ProductName ?? "Unknown Product",
                Quantity = item.Quantity,
                Price = item.Price
            };

            return CreatedAtAction(nameof(GetOrderItems), new { orderId = item.OrderId }, createdDto);
        }
    }
}
