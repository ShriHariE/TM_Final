﻿using TrendyMart.Data;
using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly TrendyMartDbContext _context;

        public ReviewRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Review> GetAll()
        {
            return _context.Reviews.ToList();
        }

        public Review GetById(int id)
        {
            return _context.Reviews.FirstOrDefault(r => r.ReviewId == id);
        }

        public IEnumerable<Review> GetByProductId(int productId)
        {
            return _context.Reviews.Where(r => r.ProductId == productId).ToList();
        }

        public void Add(Review review)
        {
            _context.Reviews.Add(review);
            _context.SaveChanges();
        }

        public void Update(Review review)
        {
            var existing = _context.Reviews.FirstOrDefault(r => r.ReviewId == review.ReviewId);
            if (existing != null)
            {
                existing.Rating = review.Rating;
                existing.Comment = review.Comment;
                existing.ReviewDate = DateTime.Now;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var review = _context.Reviews.FirstOrDefault(r => r.ReviewId == id);
            if (review != null)
            {
                _context.Reviews.Remove(review);
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.Reviews.Any(r => r.ReviewId == id);
        }
    }
}
