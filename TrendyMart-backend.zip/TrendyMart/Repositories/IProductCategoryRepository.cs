﻿using TrendyMart.Models;


namespace TrendyMart.Repositories
{
    public interface IProductCategoryRepository
    {
        IEnumerable<ProductCategory> GetAll();
        ProductCategory GetById(int id);
        void Add(ProductCategory category);
        void Update(ProductCategory category);
        void Delete(int id);
        bool Exists(int id);
    }
}

