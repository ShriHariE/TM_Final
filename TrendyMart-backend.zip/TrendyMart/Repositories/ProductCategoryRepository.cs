﻿using TrendyMart.Data;

using TrendyMart.Models;
using TrendyMart.Repositories;

namespace TrendyMart.ECommerceApp.Repositories
{
    public class ProductCategoryRepository : IProductCategoryRepository
    {
        private readonly TrendyMartDbContext _context;

        public ProductCategoryRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<ProductCategory> GetAll()
        {
            return _context.ProductCategories.ToList();
        }

        public ProductCategory GetById(int id)
        {
            return _context.ProductCategories.FirstOrDefault(c => c.CategoryId == id);
        }

        public void Add(ProductCategory category)
        {
            _context.ProductCategories.Add(category);
            _context.SaveChanges();
        }

        public void Update(ProductCategory category)
        {
            var existing = _context.ProductCategories.FirstOrDefault(c => c.CategoryId == category.CategoryId);
            if (existing != null)
            {
                existing.CategoryName = category.CategoryName;
                existing.IsActive = category.IsActive;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var category = _context.ProductCategories.FirstOrDefault(c => c.CategoryId == id);
            if (category != null)
            {
                _context.ProductCategories.Remove(category);
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.ProductCategories.Any(c => c.CategoryId == id);
        }
    }
}

