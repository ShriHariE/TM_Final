﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface ICartRepository
    {
        IEnumerable<Cart> GetAllCarts();
        Cart GetCartById(int cartId);
        void AddCart(Cart cart);
        void DeleteCart(int cartId);
        bool CartExists(int cartId);
    }
}

