﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface IUserRepository
    {
        IEnumerable<User> GetAll();
        User GetById(int id);
        void Add(User user);
        void Update(User user);
        void Delete(int id);
        bool Exists(int id);
    }
}

