﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface IOrderRepository
    {
        IEnumerable<Order> GetAll();
        Order GetById(int id);
        void Add(Order order);
        void Update(Order order);
        void Delete(int id);
        bool Exists(int id);

        IEnumerable<OrderItem> GetOrderItems(int orderId);
        void AddOrderItem(OrderItem item);
    }
}
