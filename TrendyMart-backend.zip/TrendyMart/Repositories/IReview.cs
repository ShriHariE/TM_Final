﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface IReviewRepository
    {
        IEnumerable<Review> GetAll();
        Review GetById(int id);
        IEnumerable<Review> GetByProductId(int productId);
        void Add(Review review);
        void Update(Review review);
        void Delete(int id);
        bool Exists(int id);
    }
}

