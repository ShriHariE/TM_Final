﻿using TrendyMart.Data;
using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly TrendyMartDbContext _context;

        public CartRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Cart> GetAllCarts()
        {
            return _context.Carts.ToList();
        }

        public Cart GetCartById(int cartId)
        {
            return _context.Carts.FirstOrDefault(c => c.CartId == cartId);
        }

        public void AddCart(Cart cart)
        {
            _context.Carts.Add(cart);
            _context.SaveChanges();
        }

        public void DeleteCart(int cartId)
        {
            var cart = _context.Carts.FirstOrDefault(c => c.CartId == cartId);
            if (cart != null)
            {
                _context.Carts.Remove(cart);
                _context.SaveChanges();
            }
        }

        public bool CartExists(int cartId)
        {
            return _context.Carts.Any(c => c.CartId == cartId);
        }
    }
}
