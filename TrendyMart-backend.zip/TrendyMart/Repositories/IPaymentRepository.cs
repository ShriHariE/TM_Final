﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface IPaymentRepository
    {
        IEnumerable<Payment> GetAll();
        Payment GetById(int id);
        void Add(Payment payment);
        void Update(Payment payment);
        void Delete(int id);
        bool Exists(int id);
    }
}

