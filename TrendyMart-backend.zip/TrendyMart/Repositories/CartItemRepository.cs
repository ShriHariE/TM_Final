﻿using TrendyMart.Data;
using TrendyMart.Models;
using Microsoft.EntityFrameworkCore;

namespace TrendyMart.Repositories
{
    public class CartItemRepository : ICartItemRepository
    {
        private readonly TrendyMartDbContext _context;

        public CartItemRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<CartItem> GetAll()
        {
            return _context.CartItems
                .Include(ci => ci.Product)
                .Include(ci => ci.Cart)
                .ToList();
        }

        public CartItem GetById(int id)
        {
            return _context.CartItems
                .Include(ci => ci.Product)
                .Include(ci => ci.Cart)
                .FirstOrDefault(ci => ci.CartItemId == id);
        }

        public void Add(CartItem item)
        {
            _context.CartItems.Add(item);
            _context.SaveChanges();
        }

        public void Update(CartItem item)
        {
            var existing = _context.CartItems.FirstOrDefault(ci => ci.CartItemId == item.CartItemId);
            if (existing != null)
            {
                existing.ProductId = item.ProductId;
                existing.Quantity = item.Quantity;
                existing.CartId = item.CartId;

                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var item = _context.CartItems.FirstOrDefault(ci => ci.CartItemId == id);
            if (item != null)
            {
                _context.CartItems.Remove(item);
                _context.SaveChanges();
            }
        }

        public IEnumerable<CartItem> GetItemsByCartId(int cartId)
        {
            return _context.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.CartId == cartId)
                .ToList();
        }
    }
}
