﻿namespace TrendyMart.DTOs
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public string ImageUrl { get; set; }

        // Category Information
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }

        // Seller Information
        public int SellerId { get; set; }
        public string SellerName { get; set; }

        // Active Status
        public bool IsActive { get; set; }
    }
}
