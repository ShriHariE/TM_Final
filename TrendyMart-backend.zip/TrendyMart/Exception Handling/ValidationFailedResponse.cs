﻿
namespace TrendyMart.ExceptionHandling
{
    public class ValidationFailedResponse
    {
        public bool Success { get; set; } = false;
        public string Message { get; set; } = "Validation Failed";
        public List<string> Errors { get; set; } = new List<string>();
    }
}
