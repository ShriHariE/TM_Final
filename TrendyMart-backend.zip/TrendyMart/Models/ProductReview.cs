﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrendyMart.Models
{
    public class ProductReview
    {
        [Key]
        public int ReviewId { get; set; }


        [Required]
        public int ProductId { get; set; }


        [ForeignKey("ProductId")]
        public virtual Product Product { get; set; }


        [Required]
        public int UserId { get; set; }


        [ForeignKey("UserId")]
        public virtual User User { get; set; }


        [Required]
        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5")]
        public int Rating { get; set; }


        [StringLength(1000)]
        public string ReviewText { get; set; }


        public DateTime ReviewDate { get; set; } = DateTime.Now;
    }
}

