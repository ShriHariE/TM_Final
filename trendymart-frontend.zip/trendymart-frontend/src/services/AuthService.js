// src/services/AuthService.js
import api from "./api";

export const AuthService = {
  async register(payload) {
    // { fullName, email, password, gender, contactNumber }
    const { data } = await api.post("/api/Auth/register", payload);
    return data;
  },
  async login(payload) {
    // { email, password }
    const { data } = await api.post("/api/Auth/login", payload);
    // if API returns token directly, adjust accordingly
    if (data?.token) localStorage.setItem("tm_token", data.token);
    return data;
  },
  async me() {
    const { data } = await api.get("/api/Auth/me");
    return data;
  },
  logout() {
    localStorage.removeItem("tm_token");
  },
  getToken() {
    return localStorage.getItem("tm_token");
  },
};