// src/services/OrderService.js
import api from "./api";

export const OrderService = {
  async getAll() {
    const { data } = await api.get("/api/Order/GetAll");
    return data;
  },
  async getById(id) {
    const { data } = await api.get(`/api/Order/GetById/${id}`);
    return data;
  },
  async addOrder(payload) {
    // { userId, totalAmount, ... }
    const { data } = await api.post("/api/Order/Add", payload);
    return data;
  },
  async addOrderItem(payload) {
    // { orderId, productId, quantity, price }
    const { data } = await api.post("/api/Order/AddOrderItem", payload);
    return data;
  },
  async getOrderItems(orderId) {
    const { data } = await api.get(`/api/Order/GetOrderItems/${orderId}`);
    return data;
  },
};