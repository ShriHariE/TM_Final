// src/services/ProductService.js
import api from "./api";

export const ProductService = {
  async getAll() {
    const { data } = await api.get("/api/Product/GetAllProducts");
    return data;
  },
  async getById(id) {
    const { data } = await api.get(`/api/Product/GetProductById/${id}`);
    return data;
  },
};