// src/services/api.js
import axios from "axios";

const api = axios.create({
  baseURL: "https://localhost:7024",
});

// Attach token if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("tm_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Central error logging (optional)
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err?.response?.status === 401) {
      // auto-logout on invalid token (optional)
      // localStorage.removeItem("tm_token");
    }
    return Promise.reject(err);
  }
);

export default api;