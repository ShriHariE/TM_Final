// src/services/CartItemService.js
import api from "./api";

export const CartItemService = {
  async getItemsByCartId(cartId) {
    const { data } = await api.get(`/api/CartItem/GetItemsByCartId/${cartId}`);
    return data;
  },
  async addItem(payload) {
    // { cartId, productId, quantity }
    const { data } = await api.post("/api/CartItem/Add", payload);
    return data;
  },
  async updateItem(id, payload) {
    const { data } = await api.put(`/api/CartItem/Update/${id}`, payload);
    return data;
  },
  async deleteItem(id) {
    const { data } = await api.delete(`/api/CartItem/Delete/${id}`);
    return data;
  },
};