// src/services/ReviewService.js
import api from "./api";

export const ReviewService = {
  async getByProductId(productId) {
    const { data } = await api.get(`/api/Review/GetByProductId/${productId}`);
    return data;
  },
  async add(payload) {
    // { productId, userId, rating, comment }
    const { data } = await api.post("/api/Review/Add", payload);
    return data;
  },
};