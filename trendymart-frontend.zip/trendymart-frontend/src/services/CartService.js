// src/services/CartService.js
import api from "./api";

export const CartService = {
  async getAllCarts() {
    const { data } = await api.get("/api/Cart/GetAllCarts");
    return data;
  },
  async getCartById(id) {
    const { data } = await api.get(`/api/Cart/GetCartById/${id}`);
    return data;
  },
  async addCart(payload) {
    // { userId }
    const { data } = await api.post("/api/Cart/AddCart", payload);
    return data;
  },
  async deleteCart(id) {
    const { data } = await api.delete(`/api/Cart/DeleteCart/${id}`);
    return data;
  },
};