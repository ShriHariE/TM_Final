// src/components/Navbar.js
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="nav" style={{ padding: 12, display: "flex", gap: 12, borderBottom: "1px solid #eee" }}>
      <Link to="/">TrendyMart</Link>
      <Link to="/products">Products</Link>
      <Link to="/cart">Cart</Link>
      {user ? (
        <>
          <span style={{ marginLeft: "auto" }}>Hi, {user.fullName || user.email}</span>
          <Link to="/dashboard">Dashboard</Link>
          <button onClick={logout}>Logout</button>
        </>
      ) : (
        <div style={{ marginLeft: "auto", display: "flex", gap: 12 }}>
          <Link to="/login">Login</Link>
          <Link to="/register">Register</Link>
        </div>
      )}
    </nav>
  );
}