// src/pages/Dashboard.js
import React from "react";

function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Welcome to your Dashboard</h1>
      <ul className="mt-4 list-disc list-inside">
        <li>View Profile</li>
        <li>Order History</li>
        <li>Manage Reviews</li>
      </ul>
    </div>
  );
}

export default Dashboard;