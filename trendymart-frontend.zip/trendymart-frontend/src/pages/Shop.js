// src/pages/Shop.js
import React from "react";

function Shop() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold mb-4">Shop</h1>
      <p>Explore our wide range of products available at the best prices.</p>
    </div>
  );
}

export default Shop;
