// src/pages/About.js
import React from "react";

function About() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold mb-4">About Us</h1>
      <p>
        TrendyMart is your one-stop shop for all trendy and affordable products.  
        We aim to deliver quality products with a seamless shopping experience.
      </p>
    </div>
  );
}

export default About;
