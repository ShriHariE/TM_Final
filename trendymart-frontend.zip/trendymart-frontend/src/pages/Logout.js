// src/pages/Logout.js
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Logout() {
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.removeItem("token"); // or sessionStorage
    navigate("/login");
  }, [navigate]);

  return <h2 className="p-6">Logging out...</h2>;
}

export default Logout;
