// src/pages/Home.js
import { useEffect, useState } from "react";
import { ProductService } from "../services/Productservice";
import { Link } from "react-router-dom";

export default function Home() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const data = await ProductService.getAll();
        setItems(Array.isArray(data) ? data : data?.items || []);
      } catch (e) {
        setError(e?.response?.data || e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div style={{ padding: 24 }}>Loading products…</div>;
  if (error) return <div style={{ padding: 24, color: "crimson" }}>{String(error)}</div>;

  return (
    <div style={{ padding: 24 }}>
      <h2>Products</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16 }}>
        {items.map((p) => (
          <div key={p.productId || p.id} style={{ border: "1px solid #eee", padding: 12, borderRadius: 8 }}>
            <h4>{p.name}</h4>
            <p>₹{p.price}</p>
            <Link to={`/products/${p.productId || p.id}`}>View</Link>
          </div>
        ))}
      </div>
    </div>
  );
}