// src/pages/OrderHistory.js
import React, { useState, useEffect } from "react";
import axios from "axios";

function OrderHistory() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/orders")
      .then(res => setOrders(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Order History</h1>
      {orders.length === 0 ? <p>No orders yet.</p> :
        orders.map(order => (
          <div key={order._id} className="border p-2 mb-2">
            <p>Order ID: {order._id}</p>
            <p>Status: {order.status}</p>
          </div>
        ))
      }
    </div>
  );
}

export default OrderHistory;
