// src/pages/Checkout.js
import React, { useState } from "react";

function Checkout() {
  const [formData, setFormData] = useState({
    address: "",
    city: "",
    pincode: "",
    phone: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleOrder = () => {
    alert("Order placed successfully!");
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>
      <input type="text" name="address" placeholder="Address" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input type="text" name="city" placeholder="City" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input type="text" name="pincode" placeholder="Pincode" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input type="text" name="phone" placeholder="Phone" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <button onClick={handleOrder} className="bg-blue-500 text-white px-4 py-2 rounded">Place Order</button>
    </div>
  );
}

export default Checkout;
