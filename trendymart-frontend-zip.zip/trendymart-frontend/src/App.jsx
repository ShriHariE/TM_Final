import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider, CartContext } from "./context/CartContext";
import ProtectedRoute from "./routes/ProtectedRoute";

import { useContext, useEffect, useState } from "react";
import http from "./api/http";

import Login from "./pages/auth/Login";
import Products from "./pages/products/Products";
import ProductDetails from "./pages/products/ProductDetails";
import ManageProducts from "./pages/products/ManageProducts";
import Cart from "./pages/cart/Cart";
import Unauthorized from "./pages/common/Unauthorized";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// ---------------- Header Component ----------------
const Header = () => {
  const rawRole = localStorage.getItem("role") || "";
  const role = rawRole.toLowerCase(); // ✅ normalize role
  const isLoggedIn = !!localStorage.getItem("token");
  const userId = localStorage.getItem("userId");

  const { cartRefresh } = useContext(CartContext);
  const [cartCount, setCartCount] = useState(0);

  // Fetch cart items count for logged-in user
  useEffect(() => {
    const fetchCartCount = async () => {
      if (!userId) return;
      try {
        const response = await http.get("/Cart/GetAllCarts");
        const userCart = response.data.find(cart => cart.userId == userId);
        if (userCart) {
          const itemsRes = await http.get(
            `/CartItem/GetItemsByCartId/${userCart.cartId}`
          );
          setCartCount(itemsRes.data.length);
        } else {
          setCartCount(0);
        }
      } catch (error) {
        console.error("Error fetching cart count:", error);
      }
    };
    fetchCartCount();
  }, [userId, cartRefresh]);

  return (
    <header className="bg-gray-800 text-white p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">TrendyMart</h1>
      <nav className="flex gap-4 items-center">
        <Link to="/products" className="hover:underline">
          Products
        </Link>

        {/* User Cart */}
        {isLoggedIn && role === "user" && (
          <Link to="/cart" className="relative hover:underline">
            Cart
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-3 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                {cartCount}
              </span>
            )}
          </Link>
        )}

        {/* Admin + Seller Manage Products */}
        {isLoggedIn && (role === "admin" || role === "seller") && (
          <Link to="/manage-products" className="hover:underline">
            Manage Products
          </Link>
        )}

        {/* Auth */}
        {!isLoggedIn && (
          <Link to="/login" className="hover:underline">
            Login
          </Link>
        )}
      </nav>
    </header>
  );
};
// -----------------------------------------------------------

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <Header />

          <Routes>
            {/* Public route */}
            <Route path="/login" element={<Login />} />

            {/* Protected routes for all authenticated users */}
            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<Navigate to="/products" replace />} />

              <Route path="/products" element={<Products />} />
              <Route path="/products/:id" element={<ProductDetails />} />

              <Route path="/cart" element={<Cart />} />
            </Route>

            {/* Protected route for Admin + Seller */}
            <Route
              element={<ProtectedRoute allowedRoles={["admin", "seller"]} />} // ✅ lowercase
            >
              <Route path="/manage-products" element={<ManageProducts />} />
            </Route>

            {/* Unauthorized page */}
            <Route path="/unauthorized" element={<Unauthorized />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>

        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          pauseOnHover
          draggable
          pauseOnFocusLoss
        />
      </CartProvider>
    </AuthProvider>
  );
}
