import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ProtectedRoute = ({ allowedRoles }) => {
  const { user, loading } = useAuth();

  // ✅ While fetching user → render nothing or loader
  if (loading) return <div>Loading...</div>;

  // ✅ Not logged in → redirect to login
  if (!user) return <Navigate to="/login" replace />;

  // ✅ Check roles if allowedRoles provided
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />; // ✅ Render nested routes
};

export default ProtectedRoute;
