import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import http from "../../api/http";
import { toast } from "react-toastify";

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    if (!id) return;

    const fetchProduct = async () => {
      try {
        const response = await http.get(`/Product/GetProductById/${id}`);
        setProduct(response.data);
      } catch (error) {
        console.error("Error fetching product:", error);
        toast.error("Failed to load product details");
      }
    };

    fetchProduct();
  }, [id]);

  if (!product) return <p className="text-center mt-10">Loading...</p>;

  return (
    <div className="container mx-auto p-6">
      <div className="flex gap-6">
        <img
          src={product.imageUrl || "https://via.placeholder.com/200"}
          alt={product.productName}
          className="w-64 h-64 object-cover rounded shadow"
        />
        <div>
          <h2 className="text-2xl font-bold">{product.productName}</h2>
          <p className="text-gray-600 mt-2">{product.description}</p>
          <p className="text-lg font-bold mt-4">₹ {product.price}</p>
          <button className="bg-blue-500 text-white px-4 py-2 mt-4 rounded">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
