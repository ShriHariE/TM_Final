import React, { useEffect, useState } from "react";
import http from "../../api/http";
import { toast } from "react-toastify";

const ManageProducts = () => {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({
    productId: 0,
    productName: "",
    description: "",
    price: 0,
    imageUrl: "",
  });
  const [isEdit, setIsEdit] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const res = await http.get("/Product/GetAllProducts");
      setProducts(res.data);
    } catch (err) {
      console.error(err);
      toast.error("Failed to load products");
    }
  };

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEdit) {
        await http.put(`/Product/UpdateProduct/${form.productId}`, form);
        toast.success("Product updated successfully!");
      } else {
        await http.post("/Product/AddProduct", form);
        toast.success("Product added successfully!");
      }
      setForm({ productId: 0, productName: "", description: "", price: 0, imageUrl: "" });
      setIsEdit(false);
      loadProducts();
    } catch (err) {
      console.error(err);
      toast.error("Operation failed");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure to delete this product?")) return;
    try {
      await http.delete(`/Product/DeleteProduct/${id}`);
      toast.success("Product deleted successfully!");
      loadProducts();
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete product");
    }
  };

  const handleEdit = (product) => {
    setForm({
      productId: product.productId,
      productName: product.productName,
      description: product.description,
      price: product.price,
      imageUrl: product.imageUrl || "",
    });
    setIsEdit(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Manage Products</h2>

      {/* Add/Edit Form */}
      <form onSubmit={handleSubmit} className="mb-6 space-y-2">
        <input
          type="text"
          name="productName"
          placeholder="Product Name"
          value={form.productName}
          onChange={handleChange}
          className="border p-2 w-full"
          required
        />
        <textarea
          name="description"
          placeholder="Description"
          value={form.description}
          onChange={handleChange}
          className="border p-2 w-full"
          required
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={form.price}
          onChange={handleChange}
          className="border p-2 w-full"
          required
        />
        <input
          type="text"
          name="imageUrl"
          placeholder="Image URL"
          value={form.imageUrl}
          onChange={handleChange}
          className="border p-2 w-full"
        />
        <button
          type="submit"
          className={`w-full py-2 rounded text-white ${isEdit ? "bg-blue-600" : "bg-green-600"}`}
        >
          {isEdit ? "Update Product" : "Add Product"}
        </button>
        {isEdit && (
          <button
            type="button"
            onClick={() => {
              setForm({ productId: 0, productName: "", description: "", price: 0, imageUrl: "" });
              setIsEdit(false);
            }}
            className="w-full py-2 rounded bg-gray-500 text-white mt-2"
          >
            Cancel Edit
          </button>
        )}
      </form>

      {/* List Products */}
      <div className="grid grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.productId} className="border p-4 rounded shadow">
            <h3 className="font-semibold">{product.productName}</h3>
            <p>{product.description}</p>
            <p className="font-bold">₹ {product.price}</p>
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => handleEdit(product)}
                className="bg-blue-500 text-white px-3 py-1 rounded"
              >
                Edit
              </button>
              <button
                onClick={() => handleDelete(product.productId)}
                className="bg-red-600 text-white px-3 py-1 rounded"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManageProducts;
