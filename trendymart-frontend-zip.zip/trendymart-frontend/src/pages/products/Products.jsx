import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import http from "../../api/http";
import { toast } from "react-toastify";
import { CartContext } from "../../context/CartContext";

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { triggerCartRefresh } = useContext(CartContext);
  const [cartId, setCartId] = useState(null);

  useEffect(() => {
    if (!id) return;
    const fetchProduct = async () => {
      try {
        const response = await http.get(`/Product/GetProductById/${id}`);
        setProduct(response.data);
      } catch (error) {
        console.error("Error fetching product:", error);
        toast.error("Failed to load product details");
      }
    };
    fetchProduct();
  }, [id]);

  useEffect(() => {
    // fetch or create cart
    const fetchUserCart = async () => {
      const userId = localStorage.getItem("userId");
      if (!userId) return;
      try {
        const response = await http.get("/Cart/GetAllCarts");
        let userCart = response.data.find((cart) => cart.userId === userId);
        if (!userCart) {
          const createResponse = await http.post("/Cart/AddCart", { userId });
          userCart = createResponse.data;
        }
        setCartId(userCart.cartId);
      } catch (error) {
        console.error("Error fetching or creating user cart:", error);
      }
    };
    fetchUserCart();
  }, []);

  const handleAddToCart = async () => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
      toast.error("Please login to add items to your cart");
      return;
    }
    if (!cartId) {
      toast.error("Cart not ready yet, please try again");
      return;
    }
    try {
      await http.post("/CartItem/AddCartItem", {
        cartId,
        productId: product.productId,
        quantity: 1,
        price: product.price,
      });
      toast.success(`${product.productName} added to cart`);
      triggerCartRefresh();
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast.error("Failed to add item to cart");
    }
  };

  if (!product) return <p className="text-center mt-10">Loading...</p>;

  return (
    <div className="container mx-auto p-6">
      <div className="flex gap-6">
        <img
          src={product.imageUrl || "https://via.placeholder.com/200"}
          alt={product.productName}
          className="w-64 h-64 object-cover rounded shadow"
        />
        <div>
          <h2 className="text-2xl font-bold">{product.productName}</h2>
          <p className="text-gray-600 mt-2">{product.description}</p>
          <p className="text-lg font-bold mt-4">₹ {product.price}</p>
          <button
            onClick={handleAddToCart}
            className="bg-blue-500 text-white px-4 py-2 mt-4 rounded"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
