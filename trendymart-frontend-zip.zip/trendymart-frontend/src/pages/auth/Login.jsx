import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "../../context/AuthContext";
import http from "../../api/http"; // Make sure http has baseURL set
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// ✅ Schemas
const loginSchema = z.object({
  email: z.string().min(1, "Email is required").email("Invalid email"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  fullName: z.string().min(1, "Full Name is required"),
  email: z.string().min(1, "Email is required").email("Invalid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  gender: z.string().min(1, "Gender is required"),
  contactNumber: z.string().min(10, "Contact number is required"),
  address: z.string().min(1, "Address is required"),
  role: z.string().min(1, "Role is required"),
});

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const { login } = useAuth();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(isLogin ? loginSchema : registerSchema),
  });

  const onSubmit = async (data) => {
    try {
      if (isLogin) {
        // 🔹 LOGIN
        const res = await http.post(
          "/Auth/login",
          data,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        const token = res.data?.token;

        if (token) {
          login(token); // ✅ Save token in context
          toast.success("Login successful!");
          navigate("/products");
        } else {
          toast.error("Invalid login response from server");
        }
      } else {
        // 🔹 REGISTER
        const payload = {
          fullName: data.fullName,
          email: data.email,
          password: data.password,
          gender: data.gender,
          contactNumber: data.contactNumber,
          address: data.address,
          role: data.role,
          isActive: true,
          createdAt: new Date().toISOString(),
        };

        await http.post(
          "/Auth/register",
          payload,
          { headers: { "Content-Type": "application/json" } }
        );
        toast.success("Registration successful! Please login.");
        setIsLogin(true);
      }
    } catch (err) {
      // ✅ Improved error handling
      if (err.response) {
        // Backend returned a response
        toast.error(err.response.data?.message || `Error: ${err.response.status}`);
      } else if (err.request) {
        // Request made but no response
        toast.error("No response from server. Check backend URL.");
      } else {
        // Other errors
        toast.error(err.message);
      }
      console.error("Login/Register error:", err);
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="bg-white p-6 rounded-lg shadow-lg w-[450px]">
        {/* Toggle */}
        <div className="flex justify-around mb-4">
          <button
            onClick={() => setIsLogin(true)}
            className={`w-1/2 py-2 ${isLogin ? "bg-blue-600 text-white" : "bg-gray-200"}`}
          >
            Login
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`w-1/2 py-2 ${!isLogin ? "bg-blue-600 text-white" : "bg-gray-200"}`}
          >
            Register
          </button>
        </div>

        <h2 className="text-xl font-bold mb-4 text-center">{isLogin ? "Login" : "Register"}</h2>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {!isLogin && (
            <>
              <div>
                <label className="block text-sm font-medium">Full Name</label>
                <input
                  type="text"
                  {...register("fullName")}
                  className="mt-1 w-full border rounded px-3 py-2"
                  placeholder="Enter your full name"
                />
                {errors.fullName && <p className="text-red-500 text-sm">{errors.fullName.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium">Gender</label>
                <select {...register("gender")} className="mt-1 w-full border rounded px-3 py-2">
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
                {errors.gender && <p className="text-red-500 text-sm">{errors.gender.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium">Contact Number</label>
                <input
                  type="text"
                  {...register("contactNumber")}
                  className="mt-1 w-full border rounded px-3 py-2"
                  placeholder="Enter contact number"
                />
                {errors.contactNumber && (
                  <p className="text-red-500 text-sm">{errors.contactNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium">Address</label>
                <input
                  type="text"
                  {...register("address")}
                  className="mt-1 w-full border rounded px-3 py-2"
                  placeholder="Enter your address"
                />
                {errors.address && <p className="text-red-500 text-sm">{errors.address.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium">Role</label>
                <select {...register("role")} className="mt-1 w-full border rounded px-3 py-2">
                  <option value="">Select Role</option>
                  <option value="User">User</option>
                  <option value="Seller">Seller</option>
                  <option value="Admin">Admin</option>
                </select>
                {errors.role && <p className="text-red-500 text-sm">{errors.role.message}</p>}
              </div>
            </>
          )}

          <div>
            <label className="block text-sm font-medium">Email</label>
            <input
              type="email"
              {...register("email")}
              className="mt-1 w-full border rounded px-3 py-2"
              placeholder="Enter your email"
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium">Password</label>
            <input
              type="password"
              {...register("password")}
              className="mt-1 w-full border rounded px-3 py-2"
              placeholder="Enter your password"
            />
            {errors.password && <p className="text-red-500 text-sm">{errors.password.message}</p>}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            {isSubmitting ? (isLogin ? "Logging in..." : "Registering...") : isLogin ? "Login" : "Register"}
          </button>
        </form>
      </div>
    </div>
  );
}
