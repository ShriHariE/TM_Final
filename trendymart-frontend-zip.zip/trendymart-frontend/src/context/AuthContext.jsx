import { createContext, useContext, useEffect, useMemo, useState } from "react";
import * as jwtDecode from "jwt-decode"; // ✅ works with Vite
import http from "../api/http";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem("tm_token"));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!token);

  useEffect(() => {
    const handler = () => { setToken(null); setUser(null); };
    window.addEventListener("tm:unauthorized", handler);
    return () => window.removeEventListener("tm:unauthorized", handler);
  }, []);

  useEffect(() => {
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    localStorage.setItem("tm_token", token);

    http.get("/Auth/me")
      .then(({ data }) => setUser(data))
      .catch(() => {
        try { setUser(jwtDecode(token)); }
        catch { setUser(null); }
      })
      .finally(() => setLoading(false));
  }, [token]);

  const login = (t) => setToken(t);

  const logout = () => {
    localStorage.removeItem("tm_token");
    setToken(null);
    setUser(null);
  };

  const value = useMemo(() => ({
    token,
    user,
    loading,
    login,
    logout,
    isAuthed: !!token
  }), [token, user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
