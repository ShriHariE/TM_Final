import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";
import Login from "./components/Auth/Login";
import Register from "./components/Auth/Register";
import ProductList from "./components/Products/ProductList";
import Cart from "./components/Cart/Cart";
import ProtectedRoute from "./routes/ProtectedRoute";

const App = () => (
  <AuthProvider>
    <CartProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route element={<ProtectedRoute />}>
            <Route path="/products" element={<ProductList />} />
            <Route path="/cart" element={<Cart />} />
            {/* Add other protected routes for orders, dashboard */}
          </Route>

          <Route path="*" element={<Login />} />
        </Routes>
      </Router>
    </CartProvider>
  </AuthProvider>
);

export default App;
