import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import { AuthProvider }  from "./components/Context/AuthContext";
import { CartProvider } from "./components/Context/CartContext";
import { OrderProvider } from "./components/Context/OrderContext";

import Login from "./components/Auth/Login";
import Register from "./components/Auth/Register";

import ProductList from "./components/Products/ProductList";
import ProductDetails from "./components/Products/ProductDetails";
import ManageProducts from "./components/Products/ManageProducts";

import Cart from "./components/Cart/Cart";

import OrderList from "./components/Orders/OrderList";
import OrderDetails from "./components/Orders/OrderDetails";

import AdminDashboard from "./components/Dashboard/AdminDashboard";
import SellerDashboard from "./components/Dashboard/SellerDashboard";

import ProtectedRoute from "./components/routes/ProtectedRoute";

const App = () => {
  return (
    <AuthProvider>
      <CartProvider>
        <OrderProvider>
          <Router>
            <Routes>
              {/* Public routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Protected routes (user must be logged in) */}
              <Route element={<ProtectedRoute />}>
                <Route path="/products" element={<ProductList />} />
                <Route path="/products/:id" element={<ProductDetails />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/orders" element={<OrderList />} />
                <Route path="/orders/:id" element={<OrderDetails />} />

                {/* Admin-only routes */}
                <Route element={<ProtectedRoute allowedRoles={["Admin"]} />}>
                  <Route path="/admin/dashboard" element={<AdminDashboard />} />
                  <Route path="/admin/manage-products" element={<ManageProducts />} />
                </Route>

                {/* Seller-only routes */}
                <Route element={<ProtectedRoute allowedRoles={["Seller"]} />}>
                  <Route path="/seller/dashboard" element={<SellerDashboard />} />
                  <Route path="/seller/manage-products" element={<ManageProducts />} />
                </Route>
              </Route>

              {/* Default fallback */}
              <Route path="*" element={<Login />} />
            </Routes>
          </Router>
        </OrderProvider>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;
