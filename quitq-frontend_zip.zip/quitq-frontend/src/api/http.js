import axios from "axios";

const http = axios.create({
  baseURL: "https://localhost:7024/api", // Your API base URL
});

http.interceptors.request.use((config) => {
  const token = localStorage.getItem("tm_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default http;
