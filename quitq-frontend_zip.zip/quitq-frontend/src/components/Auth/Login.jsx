import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../Context/AuthContext";
import http from "../../api/http";
import { toast } from "react-toastify";
import './authForms.css';
import { Link } from "react-router-dom";

const Login = () => {
  const { login } = useContext(AuthContext);
  const [values, setValues] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) =>
    setValues({ ...values, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await http.post("/Auth/login", values);
      const token = res.data?.token;
      if (token) {
        login(token);
        toast.success("Login successful!");
        navigate("/products");
      } else {
        toast.error("Login failed");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Login error");
    }
  };

  return (
    <div className="centered-container">

    <form onSubmit={handleSubmit} className="p-4 max-w-md mx-auto">
         <h2 className="auth-title">Login</h2>
      <input
        type="email"
        name="email"
        placeholder="Email"
        required
        value={values.email}
        onChange={handleChange}
        className="border p-2 w-full mb-4"
      />
      <input
        type="password"
        name="password"
        placeholder="Password"
        required
        value={values.password}
        onChange={handleChange}
        className="border p-2 w-full mb-4"
      />
      <button type="submit" className="bg-blue-600 text-white p-2 rounded w-full">
        Login
      </button>
       <div className="auth-footer">
        Don’t have an account?
        <Link to="/register" className="auth-link">
          Register
        </Link>
      </div>
    </form>
    </div>
  );
};

export default Login;
