import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import http from "../../api/http";
import { toast } from "react-toastify";
import './authForms.css';

import { Link } from "react-router-dom";
const Register = () => {
  const [values, setValues] = useState({
    fullName: "",
    email: "",
    password: "",
    gender: "",
    contactNumber: "",
    address: "",
    role: "",
  });
  const navigate = useNavigate();

  const handleChange = (e) =>
    setValues({ ...values, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...values,
        isActive: true,
        createdAt: new Date().toISOString(),
      };
      await http.post("/Auth/register", payload);
      toast.success("Registration successful! Please login.");
      navigate("/login");
    } catch (err) {
      toast.error(err.response?.data?.message || "Registration error");
    }
  };

  return (
    <div className="centered-container">

    <form onSubmit={handleSubmit} className="p-4 max-w-md mx-auto space-y-4">
                 <h2 className="auth-title">Register</h2>

      <input
        name="fullName"
        placeholder="Full Name"
        required
        value={values.fullName}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <select
        name="gender"
        value={values.gender}
        onChange={handleChange}
        required
        className="border p-2 w-full"
      >
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>
      <input
        name="contactNumber"
        placeholder="Contact Number"
        required
        value={values.contactNumber}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <input
        name="address"
        placeholder="Address"
        required
        value={values.address}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <select
        name="role"
        value={values.role}
        onChange={handleChange}
        required
        className="border p-2 w-full"
      >
        <option value="">Select Role</option>
        <option value="User">User</option>
        <option value="Seller">Seller</option>
        <option value="Admin">Admin</option>
      </select>
      <input
        type="email"
        name="email"
        placeholder="Email"
        required
        value={values.email}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <input
        type="password"
        name="password"
        placeholder="Password"
        required
        value={values.password}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <button type="submit" className="bg-green-600 text-white p-2 rounded w-full">
        Register
      </button>
       <div className="auth-footer">
        Already have an account?
        <Link to="/login" className="auth-link">
          Login
        </Link>
      </div>
    </form>
    </div>

  );
};

export default Register;
