import React, { useEffect, useState, useContext } from "react";
import http from "../../api/http";
import { CartContext } from "../Context/CartContext";
import { toast } from "react-toastify";

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const { cartRefresh, triggerCartRefresh } = useContext(CartContext);
  const userId = localStorage.getItem("userId");
  const [cartId, setCartId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserCart = async () => {
      if (!userId) return;
      try {
        const response = await http.get("/Cart/GetAllCarts");
        let userCart = response.data.find((cart) => cart.userId == userId);
        if (!userCart) {
          const createResponse = await http.post("/Cart/AddCart", { userId });
          userCart = createResponse.data;
        }
        setCartId(userCart.cartId);
      } catch (error) {
        toast.error("Failed to get user cart");
      } finally {
        setLoading(false);
      }
    };
    fetchUserCart();
  }, [userId]);

  useEffect(() => {
    const fetchCartItems = async () => {
      if (!cartId) return;
      try {
        const response = await http.get(`/CartItem/GetItemsByCartId/${cartId}`);
        setCartItems(response.data || []);
      } catch (error) {
        toast.error("Error fetching cart items");
      }
    };
    fetchCartItems();
  }, [cartId, cartRefresh]);

  const handleRemove = async (itemId) => {
    if (!window.confirm("Remove this item from cart?")) return;
    try {
      await http.delete(`/CartItem/Delete/${itemId}`);
      setCartItems(cartItems.filter((item) => item.cartItemId !== itemId));
      triggerCartRefresh();
      toast.success("Item removed from cart");
    } catch {
      toast.error("Failed to remove item");
    }
  };

  const handleUpdateQuantity = async (itemId, quantity) => {
    if (quantity < 1) return;
    try {
      await http.put(`/CartItem/Update/${itemId}`, { quantity });
      setCartItems((prev) =>
        prev.map((item) => (item.cartItemId === itemId ? { ...item, quantity } : item))
      );
      triggerCartRefresh();
    } catch {
      toast.error("Failed to update quantity");
    }
  };

  if (loading) return <p className="text-center mt-6">Loading your cart...</p>;

  const totalAmount = cartItems.reduce((acc, i) => acc + i.price * i.quantity, 0);

  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">My Cart</h2>

      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {cartItems.map((item) => (
            <div key={item.cartItemId} className="flex justify-between p-4 border rounded mb-2">
              <div>
                <h3 className="font-semibold">{item.productName}</h3>
                <p>₹ {item.price}</p>
                <div>
                  <button onClick={() => handleUpdateQuantity(item.cartItemId, item.quantity - 1)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => handleUpdateQuantity(item.cartItemId, item.quantity + 1)}>+</button>
                </div>
              </div>
              <div>
                <p>₹ {item.price * item.quantity}</p>
                <button onClick={() => handleRemove(item.cartItemId)} className="text-red-600">
                  Remove
                </button>
              </div>
            </div>
          ))}
          <div className="font-bold text-xl mt-4">Total: ₹ {totalAmount}</div>
          <button className="bg-green-600 text-white p-2 rounded mt-4">Proceed to Checkout</button>
        </div>
      )}
    </div>
  );
};

export default Cart;
