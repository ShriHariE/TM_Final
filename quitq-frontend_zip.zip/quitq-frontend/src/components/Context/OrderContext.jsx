import React, { createContext, useState, useEffect } from "react";
import http from "../../api/http";
import { toast } from "react-toastify";

export const OrderContext = createContext();

export const OrderProvider = ({ children }) => {
  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  const fetchOrders = async () => {
    setLoadingOrders(true);
    try {
      const res = await http.get("/Order/GetAll");
      setOrders(res.data || []);
    } catch (error) {
      toast.error("Failed to fetch orders");
    } finally {
      setLoadingOrders(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <OrderContext.Provider value={{ orders, loadingOrders, fetchOrders }}>
      {children}
    </OrderContext.Provider>
  );
};
