import React, { createContext, useState } from "react";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartRefresh, setCartRefresh] = useState(false);

  const triggerCartRefresh = () => setCartRefresh((prev) => !prev);

  return (
    <CartContext.Provider value={{ cartRefresh, triggerCartRefresh }}>
      {children}
    </CartContext.Provider>
  );
};
