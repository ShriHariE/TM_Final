import React, { createContext, useState, useEffect, useMemo } from "react";
import { jwtDecode } from "jwt-decode";


export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem("tm_token"));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!token);

  useEffect(() => {
    if (!token) {
      setUser(null);
      setLoading(false);
      localStorage.removeItem("tm_token");
      localStorage.removeItem("userId");
      return;
    }

    setLoading(true);
    localStorage.setItem("tm_token", token);

    try {
      const decoded = jwtDecode(token);
      setUser(decoded);
      // Use userId or sub depending on your token's payload
      if (decoded.userId || decoded.sub) {
        localStorage.setItem("userId", decoded.userId || decoded.sub);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, [token]);

  const login = (tok) => setToken(tok);

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("tm_token");
    localStorage.removeItem("userId");
  };

  const value = useMemo(() => ({ token, user, loading, login, logout, isAuthed: !!token }), [
    token,
    user,
    loading,
  ]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
