import React, { useEffect, useState, useContext } from "react";
import http from "../../api/http";
import { CartContext } from "../Context/CartContext";
import { toast } from "react-toastify";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const { triggerCartRefresh } = useContext(CartContext);
  const userId = localStorage.getItem("userId");
  const [cartId, setCartId] = useState(null);

  useEffect(() => {
    const fetchUserCart = async () => {
      if (!userId) return;
      try {
        const response = await http.get("/Cart/GetAllCarts");
        let userCart = response.data.find((cart) => cart.userId == userId);
        if (!userCart) {
          const createResponse = await http.post("/Cart/AddCart", { userId });
          userCart = createResponse.data;
        }
        setCartId(userCart.cartId);
      } catch (error) {
        console.error("Error fetching user cart:", error);
      }
    };
    fetchUserCart();
  }, [userId]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await http.get("/Product/GetAllProducts");
        setProducts(response.data || []);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, []);

  const handleAddToCart = async (product) => {
    if (!userId) {
      toast.error("Please login to add items to your cart");
      return;
    }
    if (!cartId) {
      toast.error("Cart not ready yet, please try again");
      return;
    }
    try {
      await http.post("/CartItem/Add", {
        cartId,
        productId: product.productId,
        quantity: 1,
        price: product.price,
      });
      toast.success(`${product.productName} added to cart`);
      triggerCartRefresh();
    } catch (error) {
      toast.error("Failed to add item to cart");
    }
  };

  return (
    <div className="p-6 grid grid-cols-3 gap-4">
      {products.map((product) => (
        <div key={product.productId} className="border p-4 rounded">
          <h3 className="font-bold">{product.productName}</h3>
          <p>{product.description}</p>
          <p>₹ {product.price}</p>
          <button
            onClick={() => handleAddToCart(product)}
            className="bg-blue-600 text-white rounded px-4 py-2 mt-2"
          >
            Add to Cart
          </button>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
