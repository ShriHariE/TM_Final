import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import http from "../../api/http";
import { toast } from "react-toastify";
import { CartContext } from "../Context/CartContext";

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { triggerCartRefresh } = useContext(CartContext);
  const userId = localStorage.getItem("userId");
  const [cartId, setCartId] = useState(null);

  useEffect(() => {
    if (!id) return;
    const fetchProduct = async () => {
      try {
        const res = await http.get(`/Product/GetProductById/${id}`);
        setProduct(res.data);
      } catch {
        toast.error("Failed to load product details");
      }
    };
    fetchProduct();
  }, [id]);

  useEffect(() => {
    const fetchUserCart = async () => {
      if (!userId) return;
      try {
        const response = await http.get("/Cart/GetAllCarts");
        let userCart = response.data.find((cart) => cart.userId === userId);
        if (!userCart) {
          const createResponse = await http.post("/Cart/AddCart", { userId });
          userCart = createResponse.data;
        }
        setCartId(userCart.cartId);
      } catch {
        toast.error("Unable to fetch cart");
      }
    };
    fetchUserCart();
  }, [userId]);

  const handleAddToCart = async () => {
    if (!userId) {
      toast.error("Please login to add items to your cart");
      return;
    }
    if (!cartId) {
      toast.error("Cart not ready yet, please try again");
      return;
    }
    try {
      await http.post("/CartItem/Add", {
        cartId,
        productId: product.productId,
        quantity: 1,
        price: product.price,
      });
      toast.success(`${product.productName} added to cart`);
      triggerCartRefresh();
    } catch {
      toast.error("Failed to add item to cart");
    }
  };

  if (!product) return <p>Loading product details...</p>;

  return (
    <div className="p-6 max-w-3xl mx-auto flex gap-6">
      <img
        src={product.imageUrl || "https://via.placeholder.com/200"}
        alt={product.productName}
        className="w-64 h-64 object-cover rounded shadow"
      />
      <div>
        <h2 className="text-2xl font-bold">{product.productName}</h2>
        <p className="mt-2">{product.description}</p>
        <p className="text-xl font-bold mt-4">₹ {product.price}</p>
        <button
          onClick={handleAddToCart}
          className="bg-blue-600 text-white px-4 py-2 rounded mt-4"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductDetails;
