import React, { useContext } from "react";
import { OrderContext } from "../Context/OrderContext";
import { Link } from "react-router-dom";

const OrderList = () => {
  const { orders, loadingOrders } = useContext(OrderContext);

  if (loadingOrders) return <p>Loading orders...</p>;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Orders</h2>
      {orders.length === 0 ? (
        <p>No orders found</p>
      ) : (
        <ul>
          {orders.map((order) => (
            <li key={order.orderId} className="border p-3 rounded mb-2">
              <p>Order #{order.orderId}</p>
              <p>Date: {new Date(order.orderDate).toLocaleDateString()}</p>
              <Link to={`/orders/${order.orderId}`} className="text-blue-600 underline">
                View Details
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default OrderList;
