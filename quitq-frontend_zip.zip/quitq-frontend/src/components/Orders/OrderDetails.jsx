import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import http from "../../api/http";
import { toast } from "react-toastify";

const OrderDetails = () => {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [items, setItems] = useState([]);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const res = await http.get(`/Order/GetById/${id}`);
        setOrder(res.data);
        const itemsRes = await http.get(`/Order/GetOrderItems/${id}`);
        setItems(itemsRes.data || []);
      } catch (error) {
        toast.error("Failed to load order details");
      }
    };
    fetchOrder();
  }, [id]);

  if (!order) return <p>Loading order...</p>;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Order #{order.orderId}</h2>
      <p>Status: {order.status || "N/A"}</p>
      <p>Date: {new Date(order.orderDate).toLocaleDateString()}</p>
      <h3 className="font-semibold mt-4">Items:</h3>
      <ul>
        {items.map((item) => (
          <li key={item.orderItemId}>
            {item.productName} - Qty: {item.quantity} - ₹ {item.price}
          </li>
        ))}
      </ul>
      <p className="font-bold mt-4">
        Total Price: ₹ {order.totalPrice || items.reduce((a,i) => a + i.price * i.quantity, 0)}
      </p>
    </div>
  );
};

export default OrderDetails;
