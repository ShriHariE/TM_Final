﻿namespace TrendyMart.DTOs
{
    public class CartItemDto
    {
        public int CartItemId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }

    public class CartDto
    {
        public int CartId { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<CartItemDto> Items { get; set; } = new List<CartItemDto>();
    }
}
