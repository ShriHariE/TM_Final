﻿namespace TrendyMart.API.Models
{
    public class RegisterModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
