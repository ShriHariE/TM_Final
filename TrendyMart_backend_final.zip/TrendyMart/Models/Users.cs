﻿using System.ComponentModel.DataAnnotations;

namespace TrendyMart.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 100 characters")]
        public string FullName { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [StringLength(10)]
        public string Gender { get; set; }

        [Phone]
        [StringLength(15)]
        public string ContactNumber { get; set; }

        [StringLength(300)]
        public string Address { get; set; }

        [Required]
        [StringLength(20)]
        public string Role { get; set; } // "User", "Seller", "Admin"

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
