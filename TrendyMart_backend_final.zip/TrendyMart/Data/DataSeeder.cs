﻿using TrendyMart.Models;

namespace TrendyMart.Data
{
    public static class DataSeeder
    {
        public static void Seed(TrendyMartDbContext context)
        {
            // 👉 Ensure database is created
            context.Database.EnsureCreated();

            // 👉 Seed Categories if none exist
            if (!context.ProductCategories.Any())
            {
                context.ProductCategories.AddRange(
                    new ProductCategory { CategoryName = "Electronics", IsActive = true },
                    new ProductCategory { CategoryName = "Fashion", IsActive = true },
                    new ProductCategory { CategoryName = "Home & Kitchen", IsActive = true }
                );
            }

            // 👉 Seed Products if none exist
            if (!context.Products.Any())
            {
                context.Products.AddRange(
                    new Product
                    {
                        ProductName = "iPhone 15",
                        Description = "Latest Apple iPhone 15 with A16 Bionic chip.",
                        Price = 79999,
                        Stock = 10,
                        ImageUrl = "https://via.placeholder.com/200x200.png?text=iPhone+15",
                        CategoryId = 1,
                        SellerId = 2, // assume Seller userId = 2
                        IsActive = true
                    },
                    new Product
                    {
                        ProductName = "Samsung Galaxy S24",
                        Description = "Flagship Samsung phone with Snapdragon 8 Gen 3.",
                        Price = 74999,
                        Stock = 15,
                        ImageUrl = "https://via.placeholder.com/200x200.png?text=Galaxy+S24",
                        CategoryId = 1,
                        SellerId = 2,
                        IsActive = true
                    },
                    new Product
                    {
                        ProductName = "Men's Jacket",
                        Description = "Winter wear stylish jacket for men.",
                        Price = 2999,
                        Stock = 25,
                        ImageUrl = "https://via.placeholder.com/200x200.png?text=Mens+Jacket",
                        CategoryId = 2,
                        SellerId = 2,
                        IsActive = true
                    },
                    new Product
                    {
                        ProductName = "Non-stick Cookware Set",
                        Description = "Premium 5-piece non-stick cookware set.",
                        Price = 4999,
                        Stock = 20,
                        ImageUrl = "https://via.placeholder.com/200x200.png?text=Cookware+Set",
                        CategoryId = 3,
                        SellerId = 2,
                        IsActive = true
                    }
                );
            }

            // 👉 Save changes
            context.SaveChanges();
        }
    }
}
