﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepo;
        private readonly IProductCategoryRepository _categoryRepo;
        private readonly IUserRepository _userRepo;

        public ProductController(IProductRepository productRepo, IProductCategoryRepository categoryRepo, IUserRepository userRepo)
        {
            _productRepo = productRepo;
            _categoryRepo = categoryRepo;
            _userRepo = userRepo;
        }

        // ✅ Anyone can view all products
        [HttpGet]
        [AllowAnonymous]
        public ActionResult<IEnumerable<ProductDto>> GetAllProducts()
        {
            var products = _productRepo.GetAll();

            var productDtos = products.Select(p => new ProductDto
            {
                ProductId = p.ProductId,
                ProductName = p.ProductName,
                Description = p.Description,
                Price = p.Price,
                Stock = p.Stock,
                ImageUrl = p.ImageUrl,
                CategoryId = p.CategoryId,
                CategoryName = _categoryRepo.GetById(p.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = p.SellerId,
                SellerName = _userRepo.GetById(p.SellerId)?.FullName ?? "Unknown",
                IsActive = p.IsActive
            }).ToList();

            return Ok(productDtos);
        }

        // ✅ Anyone can view a product by Id
        [HttpGet("{id}")]
        [AllowAnonymous]
        public ActionResult<ProductDto> GetProductById(int id)
        {
            var product = _productRepo.GetById(id);
            if (product == null)
                return NotFound($"Product with ID {id} not found");

            var dto = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                ImageUrl = product.ImageUrl,
                CategoryId = product.CategoryId,
                CategoryName = _categoryRepo.GetById(product.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = product.SellerId,
                SellerName = _userRepo.GetById(product.SellerId)?.FullName ?? "Unknown",
                IsActive = product.IsActive
            };

            return Ok(dto);
        }

        // ✅ Only Admin or Seller can add products
        [HttpPost]
        [Authorize(Roles = "Admin,Seller")]
        public ActionResult<ProductDto> AddProduct([FromBody] Product product)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _productRepo.Add(product);

            var dto = new ProductDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                ImageUrl = product.ImageUrl,
                CategoryId = product.CategoryId,
                CategoryName = _categoryRepo.GetById(product.CategoryId)?.CategoryName ?? "Unknown",
                SellerId = product.SellerId,
                SellerName = _userRepo.GetById(product.SellerId)?.FullName ?? "Unknown",
                IsActive = product.IsActive
            };

            return CreatedAtAction(nameof(GetProductById), new { id = product.ProductId }, dto);
        }

        // ✅ Only Admin or Seller can update products
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Seller")]
        public ActionResult UpdateProduct(int id, [FromBody] Product product)
        {
            if (id != product.ProductId)
                return BadRequest("Product ID mismatch");

            if (!_productRepo.Exists(id))
                return NotFound($"Product with ID {id} not found");

            _productRepo.Update(product);
            return Ok("Product updated successfully!");
        }

        // ✅ Only Admin can delete products
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteProduct(int id)
        {
            if (!_productRepo.Exists(id))
                return NotFound($"Product with ID {id} not found");

            _productRepo.Delete(id);
            return Ok("Product deleted successfully!");
        }
    }
}
