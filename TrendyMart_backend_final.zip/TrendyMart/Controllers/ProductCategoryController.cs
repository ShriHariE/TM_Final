﻿using Microsoft.AspNetCore.Mvc;
using TrendyMart.Models;
using TrendyMart.Repositories;
using TrendyMart.DTOs;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductCategoryController : ControllerBase
    {
        private readonly IProductCategoryRepository _categoryRepo;

        public ProductCategoryController(IProductCategoryRepository categoryRepo)
        {
            _categoryRepo = categoryRepo;
        }

        // GET: All Categories
        [HttpGet]
        public ActionResult<IEnumerable<ProductCategoryDto>> GetAll()
        {
            var categories = _categoryRepo.GetAll()
                .Select(c => new ProductCategoryDto
                {
                    CategoryId = c.CategoryId,
                    CategoryName = c.CategoryName,
                    IsActive = c.IsActive
                })
                .ToList();

            return Ok(categories);
        }

        // GET: Single Category by ID
        [HttpGet("{id}")]
        public ActionResult<ProductCategoryDto> GetById(int id)
        {
            var category = _categoryRepo.GetById(id);
            if (category == null)
                return NotFound($"Category with ID {id} not found.");

            var dto = new ProductCategoryDto
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                IsActive = category.IsActive
            };

            return Ok(dto);
        }

        // POST: Create Category
        [HttpPost]
        public ActionResult<ProductCategoryDto> Add([FromBody] ProductCategory category)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _categoryRepo.Add(category);

            var dto = new ProductCategoryDto
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                IsActive = category.IsActive
            };

            return CreatedAtAction(nameof(GetById), new { id = category.CategoryId }, dto);
        }

        // PUT: Update Category
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] ProductCategory category)
        {
            if (id != category.CategoryId)
                return BadRequest("Category ID mismatch.");

            if (!_categoryRepo.Exists(id))
                return NotFound($"Category with ID {id} not found.");

            _categoryRepo.Update(category);
            return NoContent();
        }

        // DELETE: Remove Category
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            if (!_categoryRepo.Exists(id))
                return NotFound($"Category with ID {id} not found.");

            _categoryRepo.Delete(id);
            return NoContent();
        }
    }
}
