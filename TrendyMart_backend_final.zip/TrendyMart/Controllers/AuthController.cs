﻿using Microsoft.AspNetCore.Mvc;
using TrendyMart.Data;
using TrendyMart.Models;
using TrendyMart.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using System.Security.Claims;

namespace TrendyMart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly TrendyMartDbContext _context;
        private readonly JwtService _jwtService;

        public AuthController(TrendyMartDbContext context, JwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;
        }

        // 1. User Registration
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            if (user == null || string.IsNullOrEmpty(user.Email) || string.IsNullOrEmpty(user.Password))
                return BadRequest("Invalid user data");

            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == user.Email);
            if (existingUser != null)
                return BadRequest("User already exists with this email");

            // Default role and active status
            user.Role = "User";
            user.IsActive = true;
            user.CreatedAt = System.DateTime.UtcNow;

            // ❗ TODO: Hash the password instead of storing plain text
            // user.Password = PasswordHasher.Hash(user.Password);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "User registered successfully!" });
        }

        // 2. User Login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest login)
        {
            if (login == null || string.IsNullOrEmpty(login.Email) || string.IsNullOrEmpty(login.Password))
                return BadRequest("Email and password are required");

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == login.Email && u.Password == login.Password && u.IsActive);

            if (user == null)
                return Unauthorized("Invalid email or password");

            // Generate JWT token
            var token = _jwtService.GenerateToken(user);

            return Ok(new
            {
                Message = "Login successful",
                Token = token,
                User = new
                {
                    user.UserId,
                    user.FullName,
                    user.Email,
                    user.Role
                }
            });
        }

        // 3. Get Current Logged-in User
        [HttpGet("me")]
        [Authorize] // ✅ requires valid JWT
        public async Task<IActionResult> Me()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
                return Unauthorized();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserId.ToString() == userIdClaim);

            if (user == null)
                return Unauthorized();

            return Ok(new
            {
                user.UserId,
                user.FullName,
                user.Email,
                user.Role,
                user.IsActive
            });
        }
    }

    // DTO for login
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
