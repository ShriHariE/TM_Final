﻿using TrendyMart.Models;
using TrendyMart.Data;

namespace TrendyMart.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly TrendyMartDbContext _context;

        public ProductRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Product> GetAll()
        {
            return _context.Products
                .Where(p => p.IsActive)
                .ToList();
        }

        public Product GetById(int id)
        {
            return _context.Products
                .FirstOrDefault(p => p.ProductId == id && p.IsActive);
        }

        public void Add(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
        }

        public void Update(Product product)
        {
            var existing = _context.Products.FirstOrDefault(p => p.ProductId == product.ProductId);
            if (existing != null)
            {
                existing.ProductName = product.ProductName;
                existing.Description = product.Description;
                existing.Price = product.Price;
                existing.Stock = product.Stock;
                existing.ImageUrl = product.ImageUrl;
                existing.CategoryId = product.CategoryId;
                existing.SellerId = product.SellerId;
                existing.IsActive = product.IsActive;

                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var product = _context.Products.FirstOrDefault(p => p.ProductId == id);
            if (product != null)
            {
                product.IsActive = false; // Soft delete
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.Products.Any(p => p.ProductId == id && p.IsActive);
        }
    }
}
