﻿using Microsoft.EntityFrameworkCore;
using TrendyMart.Data;
using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly TrendyMartDbContext _context;

        public OrderRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Order> GetAll()
        {
            return _context.Orders.Include(o => o.User).ToList();
        }

        public Order GetById(int id)
        {
            return _context.Orders.Include(o => o.User)
                                  .FirstOrDefault(o => o.OrderId == id);
        }

        public void Add(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }

        public void Update(Order order)
        {
            var existing = _context.Orders.FirstOrDefault(o => o.OrderId == order.OrderId);
            if (existing != null)
            {
                existing.TotalAmount = order.TotalAmount;
                existing.ShippingAddress = order.ShippingAddress;
                existing.PaymentStatus = order.PaymentStatus;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var order = _context.Orders.FirstOrDefault(o => o.OrderId == id);
            if (order != null)
            {
                _context.Orders.Remove(order);
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.Orders.Any(o => o.OrderId == id);
        }

        public IEnumerable<OrderItem> GetOrderItems(int orderId)
        {
            return _context.OrderItems
                .Include(oi => oi.Product)
                .Where(oi => oi.OrderId == orderId)
                .ToList();
        }

        public void AddOrderItem(OrderItem item)
        {
            _context.OrderItems.Add(item);
            _context.SaveChanges();
        }
    }
}
