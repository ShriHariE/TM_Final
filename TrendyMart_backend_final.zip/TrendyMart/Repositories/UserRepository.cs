﻿using TrendyMart.Models;
using TrendyMart.Data;
using TrendyMart.Models;
using TrendyMart.Data;

namespace TrendyMart.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly TrendyMartDbContext _context;

        public UserRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<User> GetAll()
        {
            return _context.Users
                .Where(u => u.IsActive)
                .ToList();
        }

        public User GetById(int id)
        {
            return _context.Users
                .FirstOrDefault(u => u.UserId == id && u.IsActive);
        }

        public void Add(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(User user)
        {
            var existing = _context.Users.FirstOrDefault(u => u.UserId == user.UserId);
            if (existing != null)
            {
                existing.FullName = user.FullName;
                existing.Email = user.Email;
                existing.Password = user.Password;
                existing.Gender = user.Gender;
                existing.ContactNumber = user.ContactNumber;
                existing.Address = user.Address;
                existing.Role = user.Role;
                existing.IsActive = user.IsActive;

                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.UserId == id);
            if (user != null)
            {
                user.IsActive = false; // Soft delete
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.Users.Any(u => u.UserId == id && u.IsActive);
        }
    }
}


