﻿using TrendyMart.Data;
using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly TrendyMartDbContext _context;

        public PaymentRepository(TrendyMartDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Payment> GetAll()
        {
            return _context.Payments.ToList();
        }

        public Payment GetById(int id)
        {
            return _context.Payments.FirstOrDefault(p => p.PaymentId == id);
        }

        public void Add(Payment payment)
        {
            _context.Payments.Add(payment);
            _context.SaveChanges();
        }

        public void Update(Payment payment)
        {
            var existing = _context.Payments.FirstOrDefault(p => p.PaymentId == payment.PaymentId);
            if (existing != null)
            {
                existing.PaymentMode = payment.PaymentMode;
                existing.PaymentDate = payment.PaymentDate;
                existing.Amount = payment.Amount;
                existing.OrderId = payment.OrderId;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var payment = _context.Payments.FirstOrDefault(p => p.PaymentId == id);
            if (payment != null)
            {
                _context.Payments.Remove(payment);
                _context.SaveChanges();
            }
        }

        public bool Exists(int id)
        {
            return _context.Payments.Any(p => p.PaymentId == id);
        }
    }
}

