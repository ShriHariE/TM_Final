﻿using TrendyMart.Models;

namespace TrendyMart.Repositories
{
    public interface ICartItemRepository
    {
        IEnumerable<CartItem> GetAll();
        CartItem GetById(int id);
        void Add(CartItem item);
        void Update(CartItem item);
        void Delete(int id);
        IEnumerable<CartItem> GetItemsByCartId(int cartId);
    }
}


